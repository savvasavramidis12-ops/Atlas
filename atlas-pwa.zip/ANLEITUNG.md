# ATLAS als App installieren — nur mit dem Handy

## Schritt 1: Dateien hochladen (GitHub Pages, kostenlos)
1. Öffne **github.com** im Browser → kostenlos registrieren / einloggen.
2. Oben rechts **+** → **New repository** → Name: `atlas` → Public → **Create repository**.
3. Tippe auf **"uploading an existing file"**.
4. Entpacke diese ZIP in deiner Dateien-App und lade alle 5 Dateien hoch:
   `index.html`, `manifest.json`, `sw.js`, `icon-192.png`, `icon-512.png`
5. **Commit changes**.
6. Im Repo: **Settings → Pages → Branch: main → Save**.
7. Nach 1–2 Minuten steht oben deine URL: `https://DEINNAME.github.io/atlas/`

## Schritt 2a: Sofort installieren (PWA — empfohlen)
1. Öffne die URL in **Chrome**.
2. Menü (⋮) → **"App installieren"** / **"Zum Startbildschirm hinzufügen"**.
→ ATLAS liegt als App mit Icon auf dem Homescreen, läuft im Vollbild und funktioniert offline.

## Schritt 2b: Echte APK (optional)
1. Öffne **pwabuilder.com** im Browser.
2. Deine URL einfügen → **Start** → **Package for Stores** → **Android**.
3. APK herunterladen.
4. Android: Einstellungen → "Unbekannte Apps installieren" für den Browser erlauben → APK antippen → installieren.

## AI-Coach aktivieren
Coach-Tab → 🔑 Key → eigenen Anthropic API-Key eintragen (console.anthropic.com → API Keys, Pay-as-you-go, wenige Cent pro Chat). Der Key bleibt nur auf deinem Gerät.

## Wichtig
Alle Daten (Programm, Logs, PRs, Gewicht) werden lokal auf dem Handy gespeichert. Browser-Daten der Seite nicht löschen, sonst sind die Logs weg.
